<?php
//database connection
global $conn;
if($conn==null){
include_once("../Lab11_Task1/php/connection.php");

//open the file
$file = fopen("SalaryData.txt","r");

if(!feof($file)){
while(!feof($file)){
$content = fgets($file);
$carry = explode(",",$content);
list($name,$fname,$salary) = $carry;

// prepare and bind
$stmt = $conn->prepare("INSERT INTO salarydata (Name, FName, Salary) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $name, $fname, $salary);
$stmt->execute();

}
alert("Data Loaded Sucessfully!");
echo "<center><h1>Data Loaded Sucessfully!</h1></center>";

$stmt->close();
}
else{
echo "Data Not Loaded - ".$conn->error;
}
fclose($file);
}

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
?>