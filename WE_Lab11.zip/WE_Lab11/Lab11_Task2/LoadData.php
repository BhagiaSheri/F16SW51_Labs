<?php
//database connection
global $conn;
if($conn==null){
include_once("../Lab11_Task1/php/connection.php");

$sql = "LOAD DATA INFILE 'SalaryData.txt' INTO TABLE salarydata fields terminated by ',' (Name, FName, Salary)";
mysqli_query($conn,$sql) or die(mysqli_error($conn));

alert("Data Loaded Sucessfully!");
echo "<center><h1>Data Loaded Sucessfully!</h1></center>";
}
function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
    }
?>