<?php
global $conn;
    if($conn==null){
    include_once("connection.php");
    }

$id = isset($_GET['empId']) ? $_GET['empId'] : '';

$sql = "Delete from employees where emp_id=".$id;
if ($conn->query($sql) === TRUE) {
  alert("Record Deleted");
} else {
  alert("Record Not Deleted");
}
function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

?>
