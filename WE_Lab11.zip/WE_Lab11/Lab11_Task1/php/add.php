<?php
global $conn;
    if($conn==null){
    include_once("connection.php");
    }
   
    $name = isset($_GET['name']) ? $_GET['name'] : '';
    $email = isset($_GET['email']) ? $_GET['email'] : '';
    $address = isset($_GET['address']) ? $_GET['address'] : '';
    $phone = isset($_GET['phone']) ? $_GET['phone'] : '';
// prepare and bind
$stmt = $conn->prepare("INSERT INTO employees (Name, Email, Address, Phone) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $address, $phone);

$stmt->execute();
alert("Record Inserted");
$stmt->close();

$name =  '';
$email = '';
$address = '';
$phone =  '';


function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

?>
