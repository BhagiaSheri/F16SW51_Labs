<?php
global $conn;
    if($conn==null){
    include_once("connection.php");
    }
$sql = "SELECT emp_id, Name,Email,Address,Phone FROM employees";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
   
    while($row = $result->fetch_assoc()) {
        $_SESSION["empId"] = $row["emp_id"];
        $_SESSION["name"] = $row["Name"];
        $_SESSION["email"] = $row["Email"];
        $_SESSION["address"] = $row["Address"];
        $_SESSION["phone"] = $row["Phone"];
        echo'<tr>
        <td>
            <span class="custom-checkbox">
                <input type="checkbox" id="checkbox1" name="options[]" value="'.$_SESSION["empId"].'">
                <label for="checkbox1"></label>
            </span>
        </td>';
        echo '<td>'.$row["Name"].'</td>';
        echo '<td>'.$row["Email"].'</td>';
        echo '<td>'.$row["Address"].'</td>';
        echo '<td>'.$row["Phone"].'</td>';
        echo '<td> <a href="#editEmployeeModal" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>
        <a href="#deleteEmployeeModal" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
        </td>
        </tr>';        
    }
} else {
    echo "0 results";
}
?>
