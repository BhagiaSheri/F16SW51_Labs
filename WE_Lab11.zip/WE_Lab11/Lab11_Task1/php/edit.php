<?php
global $conn;
    if($conn==null){
    include_once("connection.php");
    }

    $id = isset($_GET['empId']) ? $_GET['empId'] : '';
    $name = isset($_GET['name']) ? $_GET['name'] : '';
    $email = isset($_GET['email']) ? $_GET['email'] : '';
    $address = isset($_GET['address']) ? $_GET['address'] : '';
    $phone = isset($_GET['phone']) ? $_GET['phone'] : '';
    
// prepare and bind
$stmt = $conn->prepare("UPDATE employees SET Name =?, Email=?, Address=?, Phone=? WHERE emp_id=?");
$stmt->bind_param("ssssi", $name, $email, $address, $phone,$id);

$stmt->execute();
alert("Record Updated");
$stmt->close();

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

?>
