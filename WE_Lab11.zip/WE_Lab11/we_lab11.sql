-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2020 at 10:22 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `we_lab11`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Address` varchar(40) NOT NULL,
  `Phone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `Name`, `Email`, `Address`, `Phone`) VALUES
(22, 'Bhagia', 'bhagia@gmail.com', 'Latifabad Hyderabad\r\nPakistan', '0333-3434456'),
(25, 'Anmol', 'anmol@gmail.com', 'Mehran University of Engineering And\r\nTe', '0333-6788887'),
(26, 'Muhammad Shabbir', 'mshabbir@gmail.com', 'Latifabad Hyderabad\r\nPakistan', '0333-3434457'),
(27, 'Mashal Bhatti', 'mashal@gmail.com', 'MUET Jamshoro', '0333-2524875'),
(28, 'Aleena', 'aleena@gmail.com', 'Saddar Hyderabad\r\nPakistan', '0333-2525871'),
(29, 'Pooja', 'pooja@gmail.com', 'Qasimabad Hyderabad\r\nPakistan', '0333-3434467'),
(30, 'Mukesh', 'mukesh@gmail.com', 'Latifabad Hyderabad\r\nPakistan', '0333-7634465'),
(31, 'Ali Ahmad', 'ali@gmail.com', 'Karachi', '0333-2525899'),
(32, 'Bhawish Kumar', 'bhawish@gmail.com', 'Umerkot Pakistan', '0333-2525765');

-- --------------------------------------------------------

--
-- Table structure for table `salarydata`
--

CREATE TABLE `salarydata` (
  `id` int(30) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `FName` varchar(30) NOT NULL,
  `Salary` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salarydata`
--

INSERT INTO `salarydata` (`id`, `Name`, `FName`, `Salary`) VALUES
(1, 'Bhagia', 'Sheri', 75000),
(2, 'Pooja', 'Kumari', 75000),
(3, 'Mukesh', 'Kumar', 100000),
(4, 'Bhawish', 'Kumar', 100000),
(5, 'Ali Ahmad', 'Sheikh', 50000),
(6, 'Muhammad', 'Shah', 35000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`emp_id`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `salarydata`
--
ALTER TABLE `salarydata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `salarydata`
--
ALTER TABLE `salarydata`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
